# Matematik: kâğıt seti ve kapsama planı

Kaynak: `maarif-matematik-icerik` 3. bölüm. Soru yazmadan önce uygulanır.

Amaç: verilen çıktıların yazılıda ölçülebilen bütün süreç bileşenlerini, seçilen senaryoya birebir uyan en az sayıda sınav kâğıdının toplamında ölçmek. Kapsama tek bir kâğıtta değil, kâğıt setinin bütününde sağlanır; her kâğıt yine tek başına tam ve dengeli bir sınavdır. Bileşenleri az kâğıda sığdırmak için soruları sığ ve çok maddeli yapma; gerekiyorsa kâğıt sayısını artır.

MEB'in kendi yazılıları her bileşeni ölçmez (10. sınıf örneğinde 10.1.x soruları yalnızca en üst bileşeni, 9. sınıf örneğinde 9.1.3 yalnızca ispat bileşenini ölçer). Bütün bileşenlerin kapsanması DNAMATHOS kâğıt setinin hedefidir; tek bir sınav kâğıdının değil.

1. **Bileşenleri listele ve sınıfla:** `MAT.6.1.1-a … f`; her birine beceri basamağını yaz (`KB2.10.SB1` gibi). Her bileşeni "yazılıda ölçülür" ya da "performansa bırakılır" diye işaretle. Veri toplama planı yapma, veri toplama, grup çalışması gibi bileşenler performansa bırakılır (ör. 10.2.1-c "veri toplamak için plan yapar") ve planda "yazılı dışı" diye gösterilir.
2. **Soru başına bileşen kapasitesi (k):** MEB örneklerinde soru başına ortalama bileşen sayısı 6. sınıfta yaklaşık 1,6, 9. sınıfta 2,3, 10. sınıfta 1,9'dur. Planlamada çıkarım, ispat, çözümleme ve yorumlama çıktılarında (KB2.10, MAB1.1, KB2.4, KB2.14, KB2.11, KB2.16) k = 2; temsil ve veri çıktılarında (MAB3, MAB4) k = 3 al; bu çıktılarda adımlar doğal zincir kurar.
3. **Kâğıt sayısı kuralı:** Her çıktı için gereken soru sayısı = ⌈yazılıda ölçülen bileşen sayısı ÷ k⌉. Kâğıt sayısı = en büyük ⌈gereken soru sayısı ÷ senaryonun o çıktıya bir kâğıtta verdiği soru sayısı⌉. Senaryoda soru verilmeyen çıktı o kâğıt setine girmez. Kural MEB'in 6. sınıf havuzuyla tutarlıdır (6.1.1'in 7 bileşeni için 4 soru, 6.1.2'nin 5 bileşeni için 3 soru).
4. **Kâğıt sayısını sen belirle ve gerekçesini kullanıcıya göster:** çıktı · ölçülen bileşen sayısı · k · gereken soru · senaryodaki soru sayısı · kâğıt. Sınırlayan çıktıyı belirt. Senaryo tablosu ikincil kaynaktan geliyorsa bunu söyle.
5. **Bileşenleri kâğıtlara dağıt:** Bir soru 1–3 bileşen taşır ve bunlar komşu basamaklardır (tahmin → hesap → genelleme, sınama → önerme, önerme → ispat, araştırma sorusu → tablo → yorum). Komşu olmayan bileşenleri aynı soruya zorlama. Çekirdek bileşen (çıktının ana fiilini taşıyan) birden çok kâğıtta yer alabilir. Tek yönergeli bir soru da bir ya da iki ardışık bileşeni örtük biçimde ölçebilir.
6. **Her kâğıt senaryoya uyar:** Her kâğıtta çıktı başına soru sayısı, kullanıcının verdiği senaryodakiyle aynıdır. Kâğıtların güçlük payları birbirine yakın olur (`guclugu-belirleme.md`).
7. **Planı tablo olarak göster** ve her cevap anahtarının sonuna "Kapsama tablosu" slaytı ekle: satırlar bileşenler, sütunlar kâğıtlar (K1, K2, …), hücrelerde soru ve alt madde numarası (ör. "K2 · 3.1"); yazılı dışı bileşenler ayrı işaretlenir.
